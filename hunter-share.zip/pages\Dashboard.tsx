import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Flame, Coins, Heart, Zap, TrendingUp, Award } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Profile {
  id: string;
  name: string;
  level: number;
  exp: number;
  hp: number;
  gold_earned: number;
  gold_spent: number;
  streak: number;
  progress_percentage: number;
  current_pfp_url: string | null;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [earnedBadges, setEarnedBadges] = useState<any[]>([]);
  const [editName, setEditName] = useState("");
  const [editGoldEarned, setEditGoldEarned] = useState(0);
  const [editGoldSpent, setEditGoldSpent] = useState(0);

  useEffect(() => {
    fetchProfile();
    fetchEarnedBadges();
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (error) {
      console.error("Error fetching profile:", error);
    } else {
      setProfile(data);
      setEditName(data.name);
      setEditGoldEarned(data.gold_earned);
      setEditGoldSpent(data.gold_spent);
    }
    setLoading(false);
  };

  const fetchEarnedBadges = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("user_badges")
      .select("*, badges(*)")
      .eq("user_id", user.id)
      .limit(3);

    if (!error && data) {
      setEarnedBadges(data);
    }
  };

  const updateProfile = async () => {
    if (!user || !profile) return;

    const { error } = await supabase
      .from("profiles")
      .update({
        name: editName,
        gold_earned: editGoldEarned,
        gold_spent: editGoldSpent,
      })
      .eq("user_id", user.id);

    if (error) {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Profile Updated",
        description: "Your stats have been updated.",
      });
      fetchProfile();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="h-16 w-16 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4" />
          <p className="text-muted-foreground">Loading hunter data...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-muted-foreground">No profile found</p>
      </div>
    );
  }

  const expNeeded = profile.level * 100;
  const expProgress = (profile.exp / expNeeded) * 100;
  const goldTotal = profile.gold_earned - profile.gold_spent;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold glow-text mb-2">Hunter Profile</h1>
        <p className="text-muted-foreground">Your path to greatness</p>
      </div>

      {/* Main Profile Card */}
      <Card className="p-6 border-primary/20 glow-card">
        <div className="flex items-start gap-6">
          <Avatar className="h-32 w-32 border-4 border-primary">
            <AvatarImage src={profile.current_pfp_url || undefined} />
            <AvatarFallback className="text-4xl">{profile.name[0]}</AvatarFallback>
          </Avatar>

          <div className="flex-1 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Dialog>
                  <DialogTrigger asChild>
                    <h2 className="text-3xl font-bold cursor-pointer hover:text-primary transition-colors">
                      {profile.name}
                    </h2>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="goldEarned">Gold Earned</Label>
                        <Input
                          id="goldEarned"
                          type="number"
                          value={editGoldEarned}
                          onChange={(e) => setEditGoldEarned(parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="goldSpent">Gold Spent</Label>
                        <Input
                          id="goldSpent"
                          type="number"
                          value={editGoldSpent}
                          onChange={(e) => setEditGoldSpent(parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <Button onClick={updateProfile} className="w-full">
                        Save Changes
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                <p className="text-muted-foreground">E-Rank Hunter</p>
              </div>
              <Badge className="text-2xl px-6 py-2 bg-primary/20 text-primary border-primary/30">
                LVL {profile.level}
              </Badge>
            </div>

            {/* EXP Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-exp" />
                  EXP
                </span>
                <span className="text-muted-foreground">
                  {profile.exp} / {expNeeded}
                </span>
              </div>
              <Progress value={expProgress} className="h-3 bg-muted" />
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <Heart className="h-6 w-6 mx-auto mb-1 text-hp" />
                <p className="text-2xl font-bold">{profile.hp}</p>
                <p className="text-xs text-muted-foreground">HP</p>
              </div>

              <div className="text-center p-3 rounded-lg bg-muted/50">
                <Coins className="h-6 w-6 mx-auto mb-1 text-gold" />
                <p className="text-2xl font-bold">{goldTotal}</p>
                <p className="text-xs text-muted-foreground">Gold</p>
              </div>

              <div className="text-center p-3 rounded-lg bg-muted/50">
                <Flame className="h-6 w-6 mx-auto mb-1 text-primary" />
                <p className="text-2xl font-bold">{profile.streak}</p>
                <p className="text-xs text-muted-foreground">Streak</p>
              </div>

              <div className="text-center p-3 rounded-lg bg-muted/50">
                <TrendingUp className="h-6 w-6 mx-auto mb-1 text-secondary" />
                <p className="text-2xl font-bold">{profile.progress_percentage.toFixed(0)}%</p>
                <p className="text-xs text-muted-foreground">Progress</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Recent Badges */}
      <Card className="p-6 border-primary/20">
        <div className="flex items-center gap-2 mb-4">
          <Award className="h-5 w-5 text-primary" />
          <h3 className="text-xl font-bold">Recent Badges</h3>
        </div>
        {earnedBadges.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            Complete quests to earn badges!
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {earnedBadges.map((badge) => (
              <div
                key={badge.id}
                className="p-4 rounded-lg bg-muted/30 text-center hover:bg-muted/50 transition-colors"
              >
                {badge.badges.image_url && (
                  <img
                    src={badge.badges.image_url}
                    alt={badge.badges.name}
                    className="h-16 w-16 mx-auto mb-2 rounded-full"
                  />
                )}
                <p className="font-semibold">{badge.badges.name}</p>
                <p className="text-xs text-muted-foreground">{badge.badges.description}</p>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
